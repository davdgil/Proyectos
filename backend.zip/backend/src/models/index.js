const models ={
    usersModel: require('./nosql/users'),
    commercesModel: require('./nosql/commerce'),
    webPageModel: require('./nosql/webPage')
}

module.exports = models;